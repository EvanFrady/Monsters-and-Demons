﻿using System;

namespace EnemiesList.Classes
{
    public class Creature : Entity
    {
        private Random rand = new Random();

        public Creature()
            : base()
        {
        }
    }
}