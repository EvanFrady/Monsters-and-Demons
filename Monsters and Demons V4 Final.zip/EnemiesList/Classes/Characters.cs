﻿namespace EnemiesList.Classes
{
    public abstract class Entity
    {
        protected string _name;
        protected int _strength, _health, _defense, _gold;

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        public int Strength
        {
            get { return _strength; }
            set { _strength = value; }
        }

        public int Health
        {
            get { return _health; }
            set { _health = value; }
        }

        public int Defense
        {
            get { return _defense; }
            set { _defense = value; }
        }

        public int Gold
        {
            get { return _gold; }
            set { _gold = value; }
        }

        public Entity()
        {
            //initial property values
            Name = "";
            Strength = 0;
            Health = 0;
            Defense = 0;
            Gold = 0;
        }
    }

    /*
    public class Characters
    {
        public class Hunter
        {
            int attack = 20;
            int hp = 100;
            int defense = 1;
            int gold;
        }
        public class SlimeEasy
        {
            int attack = 1;
            int hp = 100;
            int defense = 1;
            int goldDrop = 5;
        }
        public class SlimeMedium
        {
            int attack = 5;
            int hp = 100;
            int defense = 5;
            int goldDrop = 20;
        }
        public class SlimeHard
        {
            int attack = 10;
            int hp = 100;
            int defense = 10;
            int goldDrop = 50;
        }
        public class SnakeEasy
        {
            int attack = 3;
            int hp = 100;
            int defense = 2;
            int goldDrop = 5;
        }
        public class SnakeMedium
        {
            int attack = 6;
            int hp = 100;
            int defense = 5;
            int goldDrop = 10;
        }
        public class SnakeHard
        {
            int attack = 10;
            int hp = 100;
            int defense = 10;
            int goldDrop = 100;
        }
        public class GoblinEasy
        {
            int attack = 4;
            int hp = 100;
            int defense = 5;
            int goldDrop = 10;
        }
        public class GoblinMedium
        {
            int attack = 1;
            int hp = 100;
            int defense = 1;
            int goldDrop = 5;
        }
        public class GoblinHard
        {
            int attack = 1;
            int hp = 100;
            int defense = 1;
            int goldDrop = 5;
        }
        public class CockatriceEasy
        {
            int attack = 1;
            int hp = 100;
            int defense = 1;
            int goldDrop = 5;
        }
        public class CockatriceMedium
        {
            int attack = 1;
            int hp = 100;
            int defense = 1;
            int goldDrop = 5;
        }
        public class CockatriceHard
        {
            int attack = 1;
            int hp = 100;
            int defense = 1;
            int goldDrop = 5;
        }
        public class LizardEasy
        {
            int attack = 1;
            int hp = 100;
            int defense = 1;
            int goldDrop = 5;
        }
        public class LizardMedium
        {
            int attack = 1;
            int hp = 100;
            int defense = 1;
            int goldDrop = 5;
        }
        public class LizardHard
        {
            int attack = 1;
            int hp = 100;
            int defense = 1;
            int goldDrop = 5;
        }
        public class RatEasy
        {
            int attack = 1;
            int hp = 100;
            int defense = 1;
            int goldDrop = 5;
        }
        public class RatMedium
        {
            int attack = 1;
            int hp = 100;
            int defense = 1;
            int goldDrop = 5;
        }
        public class RatHard
        {
            int attack = 1;
            int hp = 100;
            int defense = 1;
            int goldDrop = 5;
        }
        public class ScorpionEasy
        {
            int attack = 1;
            int hp = 100;
            int defense = 1;
            int goldDrop = 5;
        }
        public class ScorpionMedium
        {
            int attack = 1;
            int hp = 100;
            int defense = 1;
            int goldDrop = 5;
        }
        public class ScorpionHard
        {
            int attack = 1;
            int hp = 100;
            int defense = 1;
            int goldDrop = 5;
        }
        public class WolfEasy
        {
            int attack = 1;
            int hp = 100;
            int defense = 1;
            int goldDrop = 5;
        }
        public class WolfMedium
        {
            int attack = 1;
            int hp = 100;
            int defense = 1;
            int goldDrop = 5;
        }
        public class WolfHard
        {
            int attack = 1;
            int hp = 100;
            int defense = 1;
            int goldDrop = 5;
        }
        public class GhostEasy
        {
            int attack = 1;
            int hp = 100;
            int defense = 1;
            int goldDrop = 5;
        }
        public class GhostMedium
        {
            int attack = 1;
            int hp = 100;
            int defense = 1;
            int goldDrop = 5;
        }
        public class GhostHard
        {
            int attack = 1;
            int hp = 100;
            int defense = 1;
            int goldDrop = 5;
        }
        public class DragonEasy
        {
            int attack = 1;
            int hp = 100;
            int defense = 1;
            int goldDrop = 5;
        }
        public class DragonMedium
        {
            int attack = 1;
            int hp = 100;
            int defense = 1;
            int goldDrop = 5;
        }
        public class DragonHard
        {
            int attack = 1;
            int hp = 100;
            int defense = 1;
            int goldDrop = 5;
        }
    }*/
}